# LinkChecker

## 思路

本题编写了自定义的linker来加载动态链接库libcheck.so，在maps中不会显示加载的库，有一定的隐蔽性，也无法使用ida直接调试动态链接库，hook起来也较为复杂。调试跟入check函数将丢失静态分析的信息。

主要的校验函数在libcheck.so中，同时又调用了liblua.so执行check.lua中的lua代码校验flag。

一共有n个校验函数，其中一半在libcheck.so中，另一半在check.lua中，交替切换。

两种校验函数通过两个不同的迭代方程计算结果：

```
s = s * k + x[i]
```

```
s = (s + x[i]) * k
```

本质上是多元齐次线性方程组（希尔密码），需要选手发现规律并求解。同时校验函数较多，需要编写脚本提取参数和结果。

