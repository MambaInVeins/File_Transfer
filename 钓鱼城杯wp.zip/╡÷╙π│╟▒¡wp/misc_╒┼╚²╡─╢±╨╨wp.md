
1. `fdisk -l`查看一下当前的磁盘

2. 查看磁盘信息`mdadm -D /dev/md5`，发现这是一个raid5磁盘整列

3. 开始对进行raid5磁盘整列进行修复

```
//停止阵列
mdadm --stop /dev/md5

//重组阵列
mdadm --assemble /dev/md5 /dev/sdb /dev/sdc /dev/sdd /dev/sde --force

//根据重组结果，发现少添加了 /dev/sdb
mdadm --manage  /dev/md5  --add /dev/sdb

//重新查看阵列信息
mdadm -D  /dev/md5

//以只读的方式挂载（此步骤可以省略）
mount -o ro /dev/md5 /mnt/raid5/

//使用extundelete进行数据恢复
cd /home

extundelete --inode 2  /dev/md5

extundelete --inode 179873  /dev/md5

extundelete --restore-inode 180212  /dev/md5

cd RECOVERED_FILES/

cat file.180212

```
最后得到删除的flag值

_没考虑到各位大佬的非预期解，应该把flag再处理一下的，emmm是我太菜了！_