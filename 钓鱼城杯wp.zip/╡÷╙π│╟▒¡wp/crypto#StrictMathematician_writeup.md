# StrictMathematician

* 题目很简单，考察的其实是storage存储，主要涉及动态数组和map类型数据
* 题目没给的那部分代码其实只是对map(address)对应的数组长度的限制，如果题目分析的比较透彻，这部分是不会造成影响的

* 调用start(0x000000000000000000000000)
* 调用guess(0, 0xffffffff0000000000000153)一次
* 计算target = kecaak256(keccak256(addr|4))+3
* 计算base = keccak256(3)
* distance = (2**256-base+target) % (2**256), idx = distance // 3
    * 若distance % 3 = 0, idx = idx
    * 若distance % 3 = 1, idx += 4 ,调用guess(0, 0xffffffff0000000000000153)两次
    * 若distance % 3 = 2, idx += 2 ,掉用guess(0, 0xffffffff0000000000000153)一次

* 调用guess(0, 0xffffffff0000000000000153)三次
* 调用check(idx, 4)，其中tmp为4的倍数，在调用check之前需调用guess(0, 0xffffffff0000000000000153)的次数为tmp*3/4