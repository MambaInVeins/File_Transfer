# HTTP

## **[目的]**

掌握HTTP中Referer和cookie的使用

## **[原理]**

None

## **[步骤]**

访问发现提示 `不是本地人，不允许访问`， 于是修改xff为127.0.0.1或localhost伪造为本地

伪造后提示未登录，查看cookie发现存在login=0的键值，将0修改为1得到flag

![](./1.png)

## **[工具]**

Burpsuite