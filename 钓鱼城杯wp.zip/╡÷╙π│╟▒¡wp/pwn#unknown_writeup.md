利用`constructor`来做binary的混淆，选手需要恢复binary

堆分配的时候越界，导致一个指针被当做一个size，heap oob write.
