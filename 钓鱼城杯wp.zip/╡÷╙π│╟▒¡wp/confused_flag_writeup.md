### 【原理】
古典密码学中的变换或转置

### 【环境】
python2.7

### 【步骤】

分析题目，题目中给出了加密时的代码。

```python
import random

L = 8
perm = range(L)
random.shuffle(perm)

msg = open("/home/ctf/flag").read().strip()
while len(msg) % (2*L):
    msg += ";"

for i in xrange(100):
    msg = msg[1:] + msg[:1]
    msg = msg[0::2] + msg[1::2]
    msg = msg[1:] + msg[:1]
    res = ""
    for j in xrange(0, len(msg), L):
        for k in xrange(L):
            res += msg[j:j+L][perm[k]]
    msg = res
print (msg)
```

构建exp

```python
#!/usr/bin/env python2
from random import shuffle
import itertools
import sys

L = 8 
perm = range(L)
ps = list(itertools.permutations(perm))
msg = "BIHg}f;W;VBJOZRZUa;;D{YRPQYK;UHX;K@H;EWT;l;U;AWK"
dmsg = msg

if len(msg) % 16:
    print "wrong length"
    sys.exit(1)

def exp():
    global L, perm, msg
    for i in xrange(100):
        # 1) 根据排列，每8个字符重新排序
        res = ""
        for j in xrange(0, len(msg), L): 
            for k in xrange(L): 
                res += msg[j:j+L][perm[k]] 
        msg = res    

        # 2) 将最后一个字符移到开头
        msg = msg[-1:] + msg[:-1]

        # 3) 结合偶数和奇数字符
        evens = msg[0:int(len(msg)/2)]
        odds = msg[int(len(msg)/2):len(msg)]
        msg = ''.join(a+b for a,b in zip(evens, odds))

        # 4) 将最后一个字母移到开头
        msg = msg[-1:] + msg[:-1]


a=0
while a < len(ps):
    perm = ps[a]
    exp()
    if "flag{" in msg:
        print msg 
    msg = dmsg
    a += 1
```